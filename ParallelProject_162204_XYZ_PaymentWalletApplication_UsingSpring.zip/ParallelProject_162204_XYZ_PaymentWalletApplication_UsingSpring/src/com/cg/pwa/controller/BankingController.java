package com.cg.pwa.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pwa.bean.AccType;
import com.cg.pwa.bean.Account;
import com.cg.pwa.bean.AccountHolder;
import com.cg.pwa.bean.Transaction;
import com.cg.pwa.exception.BankingException;
import com.cg.pwa.service.BankingService;


@Controller("/bank")
public class BankingController {

	@Autowired
	private BankingService service;
	
	
	/*****************Getting Requests for Home Page***************/
	
	@RequestMapping(value="/",method=RequestMethod.GET )
	public String bankingHomeRequest()
	{
		return "BankingHome";
	}
	
	
	/*****************Getting Requests for getting Working Page***************/
	
	@RequestMapping(value="/createAcc",method=RequestMethod.GET )
	public String createNewAccountRequest(Model model, HttpServletRequest request)
	{
		AccountHolder accHolder = new AccountHolder();
		ServletContext context = request.getServletContext();
		context.setAttribute("accHolder",accHolder);
		model.addAttribute("accHolder",accHolder);
		return "AddAccountHolderDetails";
	}
	
	@RequestMapping(value="/showBal",method=RequestMethod.GET )
	public String showBalanceRequest(Model model)
	{
		return "ShowBalance";
	}
	
	@RequestMapping(value="/deposite",method=RequestMethod.GET )
	public String depositRequest(Model model)
	{
		return "Deposit";
	}
	
	@RequestMapping(value="/withdrawal",method=RequestMethod.GET )
	public String withdrawRequest(Model model)
	{
		return "Withdraw";
	}
	
	@RequestMapping(value="/fundTrans",method=RequestMethod.GET )
	public String fundTransferRequest(Model model)
	{
		return "FundTransfer";
	}
	
	@RequestMapping(value="/printTrans",method=RequestMethod.GET )
	public String printTransactionsRequest(Model model)
	{
		return "PrintTransactions";
	}
	
	@RequestMapping(value="/fetchAll",method=RequestMethod.GET )
	public String fetchAllAccountsRequest(Model model)
	{
		List<AccountHolder> accountHolders = service.fetchAllAccounts();
		model.addAttribute("accountHolders", accountHolders);
		return "FetchAllAccounts";
	}
	
	/*********************************************/
	
	
	@RequestMapping(value="/holder",method=RequestMethod.POST)
	public String createNewAccount(@Valid @ModelAttribute("accHolder") AccountHolder accHolder, BindingResult result ,Model model, HttpServletRequest request)
	{
		if(result.hasErrors())
		{
			return "AddAccountHolderDetails";
		}
		else
		{
			List<String> list = new ArrayList<>();
			list.add(AccType.Saving.toString());
			list.add(AccType.Current.toString());
			ServletContext context = request.getServletContext();
			context.setAttribute("accTypes", list);
			context.setAttribute("accHolder", accHolder);
			model.addAttribute("account", new Account());
			return "AddAccountDetails";
		}
	}

	@RequestMapping(value="/account",method=RequestMethod.POST )
	public String createNewAccountAddAccDetails(@Valid @ModelAttribute("account") Account account,BindingResult result ,Model model, HttpServletRequest request)
	{
		if(result.hasErrors())
		{
			return "AddAccountDetails";
		}
		else 
		{
			account.setOpenDate(LocalDate.now().toString());
			account.setAccNo();
			ServletContext context = request.getServletContext();
			AccountHolder accHolder=(AccountHolder)context.getAttribute("accHolder");
			accHolder.setAccount(account);
			service.createAccount(accHolder);
			model.addAttribute("accHolder", accHolder);
			return "CreateNewAccountSuccess";
		}
	}
	
	@RequestMapping(value="/balInfo",method=RequestMethod.POST)
	public String showBalance(@RequestParam("uname") String uname ,
		@RequestParam("pin") String pin, Model model, HttpServletRequest request)
				throws BankingException
	{
		double bal = service.showBalance(uname, pin);
		model.addAttribute("bal", bal);
		return "ShowBalanceSuccess";
	}
	
	@RequestMapping(value="/depositInfo",method=RequestMethod.POST)
	public String depositDetails(@RequestParam("uname") String uname ,
		@RequestParam("pin") String pin,@RequestParam("amt") String amt ,
		Model model, HttpServletRequest request)
				throws BankingException
	{

		double bal = service.deposit(uname, pin,Double.parseDouble(amt));
		model.addAttribute("bal", bal);
		return "DepositSuccess";
	}
	
	@RequestMapping(value="/withdrawInfo",method=RequestMethod.POST)
	public String withdrawDetails(@RequestParam("uname") String uname ,
		@RequestParam("pin") String pin,@RequestParam("amt") String amt ,
		Model model, HttpServletRequest request)
				throws BankingException
	{
		double bal = service.withdraw(uname, pin,Double.parseDouble(amt));
		model.addAttribute("bal", bal);	
		return "WithdrawSuccess";
	}
	

	@RequestMapping(value="/fundTransferInfo",method=RequestMethod.POST)
	public String fundTransferDetails(@RequestParam("uname") String uname ,
		@RequestParam("pin") String pin,@RequestParam("amt") String amt ,
		@RequestParam("target") String account,
		Model model, HttpServletRequest request)
				throws BankingException
	{
		double bal = service.fundTransfer(uname, pin,account,Double.parseDouble(amt));
		model.addAttribute("bal", bal);	
		return "FundTransferSuccess";
	}
	
	@RequestMapping(value="/printTransInfo",method=RequestMethod.POST)
	public String printTransactionsDetails(@RequestParam("uname") String uname ,
		@RequestParam("pin") String pin,
		Model model, HttpServletRequest request)
				throws BankingException
	{
			List<Transaction> transactions= service.printTransactions(uname, pin);
			model.addAttribute("transactions", transactions);
			
		return "PrintTransactionsSuccess";
	}
	
}

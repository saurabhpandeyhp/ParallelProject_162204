package com.cg.pwa.bean;

public enum TransType{
	Debit, Credit
}
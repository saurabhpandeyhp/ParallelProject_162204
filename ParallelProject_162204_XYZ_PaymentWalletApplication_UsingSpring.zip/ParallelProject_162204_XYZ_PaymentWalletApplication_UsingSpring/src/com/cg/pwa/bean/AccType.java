package com.cg.pwa.bean;

public enum AccType{
	Saving, Current;
}

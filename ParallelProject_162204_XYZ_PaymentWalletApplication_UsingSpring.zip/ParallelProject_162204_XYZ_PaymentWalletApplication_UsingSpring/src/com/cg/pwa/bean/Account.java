package com.cg.pwa.bean;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Acc_Spring")
public class Account {

	@Id
	@Column(length=14)
	private String accNo;
	@OneToMany(fetch= FetchType.EAGER, cascade=CascadeType.ALL)
	private List<Transaction> transactions = new ArrayList<Transaction>();
	@NotEmpty(message="Value Required for Account Type")
	@Column(length=7)
	private String accType;
	@Column(length=14)
	private Double balance;
	@Column(length=14)
	private String openDate;
	@NotNull(message="Value Required for Opening Balance")
	@Min(value=1000, message="Opening Balance must be atleast 1000")
	@Column(length=14)
	private Double openBal;
	
	public Account() {
		super();
	}
	
	public Account(String accNo,String accType, Double balance) {
		super();
		this.accNo = accNo.toString();
		this.accType = accType.toString();
		this.balance = balance;
		this.openDate = LocalDate.now().toString();
	}
	
	public Double getOpenBal() {
		return openBal;
	}
	public void setOpenBal(Double openBal) {
		this.balance = openBal;
		this.openBal = openBal;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo() {
		//this.accNo = NumberGenerator.getAccNo();
		this.accNo = String.valueOf((int)(Math.random()*1000000));
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction transaction) {
		this.transactions.add(transaction);
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	@Override
	public String toString() {
		return "\nAccount No=" + accNo +"\n accType=" + accType + "\n balance=" + balance
				+ "\n openDate=" + openDate + "]";
	}
	
	
}

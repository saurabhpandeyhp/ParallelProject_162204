package com.cg.pwa.bean;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.util.Date;
import java.util.Properties;

public class NumberGenerator {
	
	String result = "";
	InputStream inputStream;
	OutputStream outputStream;
	
	public String getPropValues() throws IOException {
		 
		try {
			Properties prop = new Properties();
			String propFileName = "NumberGenerator.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
			Date time = new Date(System.currentTimeMillis());
 
			// get the property value and print it out
			String accNo = prop.getProperty("nextId");
			result = accNo;
			System.out.println(result + "\nProgram Ran on " + time + " by Account No.=" + accNo);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	public static String getAccNo() {
		String acNo = null;
		BigInteger accNo = null;
		try {
			System.out.println("inside getAcc");
			System.out.println("hmmmm");
			Properties prop = new Properties();
			FileReader reader = new FileReader
				("NumberGenerator.properties");
			prop.load(reader);
			acNo = prop.getProperty("nextAccount");
			System.out.println(acNo);
			accNo = new BigInteger(acNo);
			System.out.println(accNo);
			reader.close();
			FileWriter writer = new FileWriter
				("NumberGenerator.properties");
			accNo = accNo.add(new BigInteger("1"));
			System.out.println(accNo);
			prop.setProperty("nextAccount", accNo.toString());
			prop.store(writer, null);
			writer.close();
		} catch (FileNotFoundException e) {
			System.out.println("NumberGenerator.properties file not found inside src directory!"); 
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return acNo;
	}
	
	public static String getuniqueId() {
		String uId = null;
		BigInteger unId = null;
		try {
			FileReader reader = new FileReader
				("NumberGenerator.properties");
			Properties prop = new Properties();
			prop.load(reader);
			uId = prop.getProperty("nextId");
			unId = new BigInteger(uId);
			reader.close();
			FileWriter writer = new FileWriter
				("NumberGenerator.properties");
			unId = unId.add(new BigInteger("1"));
			prop.setProperty("nextId", unId.toString());
			prop.store(writer, null);
			writer.close();
		} catch (FileNotFoundException e) {
			System.out.println("NumberGenerator.properties file not found inside src directory!"); 
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return uId;
	}
	
}

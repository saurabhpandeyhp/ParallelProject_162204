package com.cg.pwa.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(Exception.class)
	public ModelAndView handler(Exception ex)
	{
		ModelAndView view = new ModelAndView("Error");
		view.addObject("err", ex.getMessage());
		return view;
	}
}

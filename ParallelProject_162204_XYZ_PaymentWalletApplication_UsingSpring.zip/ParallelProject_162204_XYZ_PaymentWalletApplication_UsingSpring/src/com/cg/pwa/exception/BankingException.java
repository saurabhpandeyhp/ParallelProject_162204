package com.cg.pwa.exception;

public class BankingException extends Exception {

	private static final long serialVersionUID = 1L;

	public BankingException() {
		super();
	}
	public BankingException(String message) {
		super(message);
	}

	
}
